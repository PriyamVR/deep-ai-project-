# Weapon-Detection-and-alert-system (2020_CSE_12)
blog link: https://2020-cse-12.blogspot.com/2021/04/armament-detection-and-alert-system.html
The weights file are too large to upload on github. Please contact us for the yolo.weights file

This is our final year engineering project which is based on weapon detection

Date: 26/04/2021 
1. Till the following date we have progressed in our project idea building by referring to the following papers uploaded on our GitHub and published our own paper which is included too.
2. We conducted a survey based out of the Basavanagudi Merchant's Association group in March 2021 regarding availability of metal detectors and CCTV cameras present in stores across the area. Out of around 59 of the stores that we were able to enquire with, 42 had CCTV facilities in and around the stores and only 3 had the facility of metal detectors or any such relevant scanning facility in their stores.

3. We have accessed the requirement specifications and have cornered out on the twilio API, which we will be using.

Date: 03/05/2021 


1. We conducted a survey based out of the Basavanagudi Merchant's Association group in March 2021 regarding availability of metal detectors and CCTV cameras present in stores across the area. Out of the stores that we were able to enquire with, 65-70% had CCTV facilities in and around the stores and only around 5% had the facility of metal detectors or any such relevant scanning facility in their stores.

2. We have accessed the requirement specifications and have cornered out on the twilio API, which we will be using.
Twilio  is an American cloud communications platform as a service (CPaaS) that allows software developers to programmatically make and receive phone calls using its web service APIs.

3. We have implemented twilio as a standalone function for calling and we have found satisfactory results where the code proceeds to call the given number when executed

Date: 10/05/2021

Image Input and Detection Software: 

1. OPENCV: For the video input we will be using open-source computer vision (opencv).OpenCV runs on all popular desktop operating systems. It is an open-source library computer vision. It provides the facility to the machine to recognize faces, objects etc. OpenCV is available for free of cost. Since the OpenCV library is written in C/C++, so it is quite fast. Now it can be used with Python. It require less RAM to usage, it maybe of 60-70 MB. Computer Vision is portable as OpenCV and can run on any device that can run on C.

2. YOLO: You only look once (YOLO) is a state-of-the-art, real-time object detection system. YOLO reasons at the level of the overall image, rather than examining successively several regions. We are implementing yolo because of its real-time advantages over others

Date: 31/05/2021


1. We have trained the model for weapon detection.

2. We have successfully generated the weights file 

3. We will be using the same for detection in out project.

Date: 07/06/2021
1. Working on motion control

2. Working on how camera can be invoked when motion can be detected

3. Further upon this we should be able to start our main detection and alerting module.
